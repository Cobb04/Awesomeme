#if os(macOS)
import AppKit
import Carbon.HIToolbox

extension KeyboardShortcuts {
	/**
	A `NSView` that lets the user record a keyboard shortcut.

	You would usually put this in your settings window.

	It automatically prevents choosing a keyboard shortcut that is already taken by the system or by the app's main menu by showing a user-friendly alert to the user.

	It takes care of storing the keyboard shortcut in `UserDefaults` for you when initialized with a name. When initialized with a shortcut value, it reads and writes the shortcut through the `shortcut` property.

	- Note: When initialized with a shortcut value, the shortcut is not automatically registered as a global hotkey. You are responsible for storing and handling the shortcut yourself.

	```swift
	import AppKit
	import KeyboardShortcuts

	final class SettingsViewController: NSViewController {
		override func loadView() {
			view = NSView()

			let recorder = KeyboardShortcuts.RecorderCocoa(for: .toggleUnicornMode)
			view.addSubview(recorder)
		}
	}
	```
	*/
	public final class RecorderCocoa: NSSearchField, NSSearchFieldDelegate {
		// The active recorder owns the shared paused state. A weak reference lets delayed cleanup distinguish stale recorders without extending their lifetime.
		private static weak var activeRecorder: RecorderCocoa?

		private enum StorageMode {
			case name
			case binding
		}

		private let minimumWidth = 130.0
		private let onChange: ((_ shortcut: Shortcut?) -> Void)?
		private let storageMode: StorageMode
		private var bindingShortcut: Shortcut?
		private var canBecomeKey = false
		private var eventMonitor: LocalEventMonitor?
		private var shortcutsNameChangeObserver: NSObjectProtocol?
		private var windowDidResignKeyObserver: NSObjectProtocol?
		private var windowDidBecomeKeyObserver: NSObjectProtocol?

		/**
		A closure that validates a shortcut before it is saved.

		Use this to prevent assigning shortcuts that are already in use by other actions or to block certain shortcuts.

		```swift
		let recorder = KeyboardShortcuts.RecorderCocoa(for: .action1)

		recorder.validateShortcut = { shortcut in
			let others: [KeyboardShortcuts.Name] = [.action2, .action3]

			if let conflict = others.first(where: { $0.shortcut == shortcut }) {
				return .disallow(reason: "This shortcut is already used by “\(conflict.rawValue)”.")
			}

			return .allow
		}
		```
		*/
		public var validateShortcut: ((_ shortcut: Shortcut) -> ValidationResult)?

		/**
		Controls how the recorder handles keyboard shortcut conflicts with menu items, system shortcuts, and disallowed shortcuts.
		*/
		public var conflictPolicy = ConflictPolicy.default

		/**
		The shortcut name for the recorder.

		Can be dynamically changed at any time.

		This is only used when initialized with a name. In binding mode, changing this has no effect.
		*/
		public var shortcutName: Name {
			didSet {
				guard storageMode == .name else {
					assertionFailure("shortcutName is only available when initialized with a name.")
					return
				}

				guard shortcutName != oldValue else {
					return
				}

				updateStringValue()

				// This doesn't seem to be needed anymore, but I cannot test on older OS versions, so keeping it just in case.
				if #unavailable(macOS 12) {
					DispatchQueue.main.async { [self] in
						// Prevents the placeholder from being cut off.
						blur()
					}
				}
			}
		}

		/**
		The shortcut for the recorder.

		Use this when you manage the shortcut storage yourself.
		*/
		public var shortcut: Shortcut? {
			get { currentShortcut }
			set {
				guard newValue != currentShortcut else {
					return
				}

				storeShortcut(newValue)
				updateStringValue()
			}
		}

		@_documentation(visibility: private)
		override public var canBecomeKeyView: Bool { canBecomeKey }

		@_documentation(visibility: private)
		override public var intrinsicContentSize: CGSize {
			var size = super.intrinsicContentSize
			size.width = minimumWidth
			return size
		}

		// Center the text in the full field width, not just the area left of the cancel button. On macOS 27+, NSSearchField uses subviews for text layout: a clip view when focused and a label when not. Mirror the right-side inset (cancel button) to the left so center-aligned text is visually centered in the whole field.
		@_documentation(visibility: private)
		override public func layout() {
			super.layout()

			guard #available(macOS 27, *) else {
				return
			}

			for subview in subviews {
				let name = NSStringFromClass(type(of: subview))

				guard name.contains("ClipView") || name.contains("SimpleLabel") else {
					continue
				}

				let rightInset = bounds.width - subview.frame.maxX

				guard rightInset > subview.frame.minX else {
					continue
				}

				subview.frame = NSRect(
					x: rightInset,
					y: subview.frame.minY,
					width: bounds.width - rightInset * 2,
					height: subview.frame.height
				)
			}
		}

		private var cancelButton: NSButtonCell?

		private var showsCancelButton: Bool {
			get { (cell as? NSSearchFieldCell)?.cancelButtonCell != nil }
			set {
				(cell as? NSSearchFieldCell)?.cancelButtonCell = newValue ? cancelButton : nil
			}
		}

		/**
		- Parameter name: Strongly-typed keyboard shortcut name.
		- Parameter onChange: Callback which will be called when the keyboard shortcut is changed/removed by the user. This can be useful when you need more control. For example, when migrating from a different keyboard shortcut solution and you need to store the keyboard shortcut somewhere yourself instead of relying on the built-in storage. However, it's strongly recommended to just rely on the built-in storage when possible.
		*/
		public required init(
			for name: Name,
			onChange: ((_ shortcut: Shortcut?) -> Void)? = nil
		) {
			self.shortcutName = name
			self.onChange = onChange
			self.storageMode = .name

			// Use a default frame that matches our intrinsic size to prevent zero-size issues
			// when added without constraints (issue #209)
			super.init(frame: NSRect(x: 0, y: 0, width: minimumWidth, height: 24))
			configureView()

			updateStringValue()

			setUpEvents()
		}

		/**
		- Parameter shortcut: The initial keyboard shortcut value.
		- Parameter onChange: Callback which will be called when the keyboard shortcut is changed/removed by the user.
		*/
		public required init(
			shortcut: Shortcut?,
			onChange: ((_ shortcut: Shortcut?) -> Void)? = nil
		) {
			self.shortcutName = Name(rawValueWithoutInitialization: "")
			self.onChange = onChange
			self.storageMode = .binding
			self.bindingShortcut = shortcut

			// Use a default frame that matches our intrinsic size to prevent zero-size issues
			// when added without constraints (issue #209)
			super.init(frame: NSRect(x: 0, y: 0, width: minimumWidth, height: 24))
			configureView()

			updateStringValue()
		}

		@available(*, unavailable)
		public required init?(coder: NSCoder) {
			fatalError("init(coder:) has not been implemented")
		}

		isolated deinit {
			removeObserver(&shortcutsNameChangeObserver)
			removeObserver(&windowDidResignKeyObserver)
			removeObserver(&windowDidBecomeKeyObserver)
		}

		private func configureView() {
			delegate = self
			placeholderString = "record_shortcut".localized
			alignment = .center
			(cell as? NSSearchFieldCell)?.searchButtonCell = nil

			wantsLayer = true
			setContentHuggingPriority(.defaultHigh, for: .vertical)
			setContentHuggingPriority(.defaultHigh, for: .horizontal)

			// Hide the cancel button when not showing the shortcut so the placeholder text is properly centered. Must be last.
			cancelButton = (cell as? NSSearchFieldCell)?.cancelButtonCell
		}

		private func removeObserver(_ observer: inout NSObjectProtocol?) {
			guard let existingObserver = observer else {
				return
			}

			NotificationCenter.default.removeObserver(existingObserver)
			observer = nil
		}

		private var currentShortcut: Shortcut? {
			switch storageMode {
			case .name:
				return getShortcut(for: shortcutName)
			case .binding:
				return bindingShortcut
			}
		}

		private func storeShortcut(_ shortcut: Shortcut?) {
			switch storageMode {
			case .name:
				setShortcut(shortcut, for: shortcutName)
			case .binding:
				bindingShortcut = shortcut
			}
		}

		private func updateStringValue() {
			stringValue = currentShortcut.map { "\($0)" } ?? ""

			// If `stringValue` is empty, hide the cancel button to let the placeholder center.
			showsCancelButton = !stringValue.isEmpty
		}

		private func setUpEvents() {
			guard storageMode == .name else {
				return
			}

			shortcutsNameChangeObserver = NotificationCenter.default.addObserver(forName: .shortcutByNameDidChange, object: nil, queue: nil) { [weak self] notification in
				let nameInNotification = notification.keyboardShortcutsName

				Task { @MainActor [weak self] in
					guard
						let self,
						let nameInNotification,
						nameInNotification == shortcutName
					else {
						return
					}

					updateStringValue()
				}
			}
		}

		private func endRecording() {
			eventMonitor = nil
			placeholderString = "record_shortcut".localized
			showsCancelButton = !stringValue.isEmpty
			restoreCaret()

			guard Self.activeRecorder === self else {
				return
			}

			Self.activeRecorder = nil
			KeyboardShortcuts.isPaused = false
			NotificationCenter.default.post(name: .recorderActiveStatusDidChange, object: nil, userInfo: [NotificationUserInfoKey.isActive: false])
		}

		private func preventBecomingKey() {
			canBecomeKey = false

			// Prevent the control from receiving the initial focus.
			Task { @MainActor [weak self] in
				self?.canBecomeKey = true
			}
		}

		@_documentation(visibility: private)
		public func controlTextDidChange(_ object: Notification) {
			if stringValue.isEmpty {
				saveShortcut(nil)
			}

			showsCancelButton = !stringValue.isEmpty

			if stringValue.isEmpty {
				// Hack to ensure that the placeholder centers after the above `showsCancelButton` setter.
				focus()
			}
		}

		@_documentation(visibility: private)
		public func controlTextDidEndEditing(_ object: Notification) {
			// The window reuses its field editor, so restore the caret while this recorder still owns it. If AppKit restarts editing, the deferred check hides it again.
			restoreCaret()

			// AppKit (macOS 26 and later) ends and restarts editing internally, for example when the placeholder changes while the field editor is installed or when a click starts editing. Those restarts post this notification too, so deciding synchronously would end the recording right after it started. By the next turn, a restart has editing active again while a real end has removed the field editor.
			Task { @MainActor [weak self] in
				guard let self else {
					return
				}

				if
					let editor = currentEditor(),
					window?.firstResponder === editor
				{
					hideCaret()
					return
				}

				endRecording()
			}
		}

		@_documentation(visibility: private)
		override public func viewDidMoveToWindow() {
			guard let window else {
				removeObserver(&windowDidResignKeyObserver)
				removeObserver(&windowDidBecomeKeyObserver)
				endRecording()
				return
			}

			removeObserver(&windowDidResignKeyObserver)
			removeObserver(&windowDidBecomeKeyObserver)

			// Ensures the recorder stops when the window is hidden.
			// This is especially important for Settings windows, which as of macOS 13.5, only hides instead of closes when you click the close button.
			windowDidResignKeyObserver = NotificationCenter.default.addObserver(forName: NSWindow.didResignKeyNotification, object: window, queue: nil) { [weak self] _ in
				Task { @MainActor [weak self] in
					guard
						let self,
						let window = self.window
					else {
						return
					}

					endRecording()
					window.makeFirstResponder(nil)
				}
			}

			// Ensures the recorder does not receive initial focus when a hidden window becomes unhidden.
			windowDidBecomeKeyObserver = NotificationCenter.default.addObserver(forName: NSWindow.didBecomeKeyNotification, object: window, queue: nil) { [weak self] _ in
				Task { @MainActor [weak self] in
					self?.preventBecomingKey()
				}
			}

			preventBecomingKey()
		}

		@_documentation(visibility: private)
		override public func becomeFirstResponder() -> Bool {
			// Ensure we have a valid window before attempting to become first responder
			// This prevents issues in SwiftUI contexts where the view hierarchy might not be fully established
			guard window != nil else {
				return false
			}

			let shouldBecomeFirstResponder = super.becomeFirstResponder()

			guard shouldBecomeFirstResponder else {
				return shouldBecomeFirstResponder
			}

			placeholderString = "press_shortcut".localized
			showsCancelButton = !stringValue.isEmpty
			hideCaret()
			Self.activeRecorder = self
			KeyboardShortcuts.isPaused = true // The position here matters.
			NotificationCenter.default.post(name: .recorderActiveStatusDidChange, object: nil, userInfo: [NotificationUserInfoKey.isActive: true])

			eventMonitor = LocalEventMonitor(events: [.keyDown, .leftMouseUp, .rightMouseUp]) { [weak self] event in
				guard let self else {
					return nil
				}

				let clickPoint = convert(event.locationInWindow, from: nil)
				let clickMargin = 3.0

				// Mouse up is monitored only to end recording when the user clicks outside the field. Mouse events are never swallowed: `NSSearchFieldCell` fires the cancel button on mouse up, so consuming a click inside the field would make the clear button do nothing.
				if event.type == .leftMouseUp || event.type == .rightMouseUp {
					if !isMousePoint(clickPoint, in: bounds.insetBy(dx: -clickMargin, dy: -clickMargin)) {
						blur()
					}

					return event
				}

				guard event.isKeyEvent else {
					return nil
				}

				if event.modifiers.isEmpty {
					switch event.specialKey {
					case .tab:
						blur()

						// We intentionally bubble up the event so it can focus the next responder.
						return event
					case .delete, .deleteForward, .backspace:
						clear()
						return nil
					default:
						break
					}

					if event.keyCode == kVK_Escape { // TODO: Make this strongly typed.
						blur()
						return nil
					}
				}

				// The “shift” key is not allowed without other modifiers or a function key, since it doesn't actually work.
				guard
					!event.modifiers.subtracting([.shift, .function]).isEmpty
						|| event.specialKey?.isFunctionKey == true,
					let shortcut = Shortcut(event: event)
				else {
					NSSound.beep()
					return nil
				}

				if let menuItem = shortcut.menuItemTakenByMainMenu(currentShortcut: currentShortcut) {
					let title = String.localizedStringWithFormat("keyboard_shortcut_used_by_menu_item".localized, menuItem.title)
					// TODO: Find a better way to make it possible to dismiss the alert by pressing "Enter". How can we make the input automatically temporarily lose focus while the alert is open?
					guard handleConflict(conflictPolicy.menuItem, title: title) else {
						return nil
					}
				}

				// See: https://developer.apple.com/forums/thread/763878?answerId=804374022#804374022
				if shortcut.isDisallowed, conflictPolicy.disallowed != .allow {
					showAlert(title: "keyboard_shortcut_disallowed".localized)
					return nil
				}

				// TODO: Add button to offer to open the relevant system settings pane for the user.
				if shortcut.isTakenBySystem {
					guard handleConflict(conflictPolicy.systemShortcut, title: "keyboard_shortcut_used_by_system".localized, message: "keyboard_shortcuts_can_be_changed".localized) else {
						return nil
					}
				}

				if case .disallow(let reason) = validateShortcut?(shortcut) {
					showAlert(title: reason)
					return nil
				}

				stringValue = "\(shortcut)"
				showsCancelButton = true

				saveShortcut(shortcut)
				blur()

				return nil
			}.start()

			return shouldBecomeFirstResponder
		}

		private func saveShortcut(_ shortcut: Shortcut?) {
			storeShortcut(shortcut)
			onChange?(shortcut)
		}

		/**
		Returns `true` if the shortcut should be saved, `false` if it was blocked by the user or policy.
		*/
		private func handleConflict(_ behavior: ConflictBehavior, title: String, message: String? = nil) -> Bool {
			switch behavior {
			case .block:
				showAlert(title: title, message: message)
				return false
			case .warn:
				let response = showAlert(title: title, message: message, buttonTitles: ["ok".localized, "force_use_shortcut".localized])
				return response == .alertSecondButtonReturn
			case .allow:
				return true
			}
		}

		@discardableResult
		private func showAlert(
			title: String,
			message: String? = nil,
			buttonTitles: [String] = []
		) -> NSApplication.ModalResponse {
			blur()

			let response = NSAlert.showModal(
				for: window,
				title: title,
				message: message,
				buttonTitles: buttonTitles
			)

			focus()
			return response
		}
	}
}

extension Notification.Name {
	static let recorderActiveStatusDidChange = Self("KeyboardShortcuts_recorderActiveStatusDidChange")
}
#endif
