import SwiftUI
#if DEBUG
import os
#endif
#if DEBUG && canImport(OSLog)
import OSLog
#endif

#if os(macOS)
import Carbon.HIToolbox


extension String {
	/**
	Makes the string localizable.
	*/
	var localized: String {
		NSLocalizedString(self, bundle: .module, comment: self)
	}
}


extension Data {
	nonisolated var toString: String? { String(data: self, encoding: .utf8) }
}


extension NSEvent {
	nonisolated var isKeyEvent: Bool { type == .keyDown || type == .keyUp }
}


extension NSTextField {
	func hideCaret() {
		(currentEditor() as? NSTextView)?.insertionPointColor = .clear
	}

	func restoreCaret() {
		(currentEditor() as? NSTextView)?.insertionPointColor = .labelColor
	}
}


extension NSView {
	func focus() {
		window?.makeFirstResponder(self)
	}

	func blur() {
		window?.makeFirstResponder(nil)
	}
}


/**
Listen to local events.

- Important: Don't forget to call `.start()`.

```swift
eventMonitor = LocalEventMonitor(events: [.leftMouseDown, .rightMouseDown]) { event in
	// Do something

	return event
}
.start()
```
*/
final class LocalEventMonitor {
	private let events: NSEvent.EventTypeMask
	private let callback: (NSEvent) -> NSEvent?
	// Must be strong. The object returned by `addLocalMonitorForEvents` is owned by the caller and must be kept alive until it's passed to `removeMonitor`. It used to be weak, which worked only because AppKit happened to retain it internally. On some macOS 26/27 builds it was deallocated as soon as the autorelease pool drained, so the monitor silently stopped receiving events and `stop()` never removed it.
	private var monitor: AnyObject?

	init(events: NSEvent.EventTypeMask, callback: @escaping (NSEvent) -> NSEvent?) {
		self.events = events
		self.callback = callback
	}

	isolated deinit {
		stop()
	}

	@discardableResult
	func start() -> Self {
		guard monitor == nil else {
			return self
		}

		monitor = NSEvent.addLocalMonitorForEvents(matching: events, handler: callback) as AnyObject
		return self
	}

	func stop() {
		guard let monitor else {
			return
		}

		NSEvent.removeMonitor(monitor)
		self.monitor = nil
	}
}


final class RunLoopLocalEventMonitor {
	private let runLoopMode: RunLoop.Mode
	private let callback: (NSEvent) -> NSEvent?
	private let observer: CFRunLoopObserver
	private var isStarted = false

	init(
		events: NSEvent.EventTypeMask,
		runLoopMode: RunLoop.Mode,
		callback: @escaping (NSEvent) -> NSEvent?
	) {
		self.runLoopMode = runLoopMode
		self.callback = callback
		var pendingEvents = [NSEvent]()

		self.observer = CFRunLoopObserverCreateWithHandler(nil, CFRunLoopActivity.beforeSources.rawValue, true, 0) { _, _ in
			// Peek the head of the queue without dequeuing, and only pull an event when the head is one we handle.
			// While a menu is tracking, the queue is a flood of mouse-moved events. Asking `nextEvent(matching: keyMask, dequeue: true)` to return the key events forces AppKit to scan and drain that whole flood out of the window-server port on every run-loop iteration, which starves the menu's own event tracking and makes the highlight lag badly. Peeking the head stops the moment a mouse-moved event is in front, so the menu keeps consuming its events undisturbed, while any key event that reaches the head is still handled.
			// Trade-off: a key event queued behind mouse-moved events is handled on a later pass, once the menu drains the events ahead of it. In practice the pointer is still while a shortcut is pressed, so the flood clears and the key surfaces within a pass or two.
			pendingEvents.removeAll(keepingCapacity: true)

			// Collect the leading run of handled events, then re-post the unconsumed ones after the loop. Re-posting inside the loop would send an unconsumed event back to the head and immediately re-peek it, spinning forever.
			while
				// Only the peek (`dequeue: false`) is cheap. Guard on the head's type first so we dequeue nothing while a mouse-moved event is in front.
				let head = NSApp.nextEvent(matching: .any, until: nil, inMode: runLoopMode, dequeue: false),
				events.contains(NSEvent.EventTypeMask(rawValue: 1 << head.type.rawValue)),
				// The head matches, so this dequeues that same event.
				let event = NSApp.nextEvent(matching: events, until: nil, inMode: runLoopMode, dequeue: true)
			{
				// The callback returns `nil` when it consumes the event (a matching shortcut), otherwise the event to re-post for normal handling.
				if let handledEvent = callback(event) {
					pendingEvents.append(handledEvent)
				}
			}

			// Restore unconsumed events ahead of the untouched queue, preserving their original order.
			for eventToRepost in pendingEvents.reversed() {
				NSApp.postEvent(eventToRepost, atStart: true)
			}
		}
	}

	isolated deinit {
		stop()
	}

	@discardableResult
	func start() -> Self {
		guard !isStarted else {
			return self
		}

		isStarted = true
		CFRunLoopAddObserver(RunLoop.current.getCFRunLoop(), observer, CFRunLoopMode(runLoopMode.rawValue as CFString))
		return self
	}

	func stop() {
		guard isStarted else {
			return
		}

		isStarted = false
		CFRunLoopRemoveObserver(RunLoop.current.getCFRunLoop(), observer, CFRunLoopMode(runLoopMode.rawValue as CFString))
	}
}


extension NSEvent {
	private static func normalizedModifiers(from flags: ModifierFlags) -> ModifierFlags {
		flags
			.intersection(.deviceIndependentFlagsMask)
			// We remove `capsLock` as it shouldn't affect the modifiers.
			// We remove `numericPad` as arrow keys trigger it, use `event.specialKeys` instead.
			.subtracting([.capsLock, .numericPad])
	}

	static var modifiers: ModifierFlags {
		normalizedModifiers(from: modifierFlags)
	}

	/**
	Real modifiers.

	- Note: Prefer this over `.modifierFlags`.

	```swift
	// Check if Command is one of possible more modifiers keys
	event.modifiers.contains(.command)

	// Check if Command is the only modifier key
	event.modifiers == .command

	// Check if Command and Shift are the only modifiers
	event.modifiers == [.command, .shift]
	```
	*/
	var modifiers: ModifierFlags {
		Self.normalizedModifiers(from: modifierFlags)
	}
}


extension NSSearchField {
	/**
	Clear the search field.
	*/
	func clear() {
		(cell as? NSSearchFieldCell)?.cancelButtonCell?.performClick(self)
	}
}


extension NSAlert {
	/**
	Show an alert as a window-modal sheet, or as an app-modal (window-independent) alert if the window is `nil` or not given.
	*/
	@discardableResult
	static func showModal(
		for window: NSWindow? = nil,
		title: String,
		message: String? = nil,
		style: Style = .warning,
		icon: NSImage? = nil,
		buttonTitles: [String] = []
	) -> NSApplication.ModalResponse {
		NSAlert(
			title: title,
			message: message,
			style: style,
			icon: icon,
			buttonTitles: buttonTitles
		).runModal(for: window)
	}

	convenience init(
		title: String,
		message: String? = nil,
		style: Style = .warning,
		icon: NSImage? = nil,
		buttonTitles: [String] = []
	) {
		self.init()
		self.messageText = title
		self.alertStyle = style
		self.icon = icon

		for buttonTitle in buttonTitles {
			addButton(withTitle: buttonTitle)
		}

		if let message {
			self.informativeText = message
		}
	}

	/**
	Runs the alert as a window-modal sheet, or as an app-modal (window-independent) alert if the window is `nil` or not given.
	*/
	@discardableResult
	func runModal(for window: NSWindow? = nil) -> NSApplication.ModalResponse {
		guard let window else {
			return runModal()
		}

		beginSheetModal(for: window) { returnCode in
			NSApp.stopModal(withCode: returnCode)
		}

		return NSApp.runModal(for: window)
	}
}


enum UnicodeSymbols {
	/**
	Represents the Function (Fn) key on the keyboard.
	*/
	nonisolated static let functionKey = "🌐\u{FE0E}"
}


extension NSEvent.ModifierFlags {
	// Not documented anywhere, but reverse-engineered by me.
	nonisolated private static let functionKey = 1 << 17 // 131072 (0x20000)

	nonisolated var carbon: Int {
		var modifierFlags = 0

		if contains(.control) {
			modifierFlags |= controlKey
		}

		if contains(.option) {
			modifierFlags |= optionKey
		}

		if contains(.shift) {
			modifierFlags |= shiftKey
		}

		if contains(.command) {
			modifierFlags |= cmdKey
		}

		if contains(.function) {
			modifierFlags |= Self.functionKey
		}

		return modifierFlags
	}

	nonisolated init(carbon: Int) {
		self.init()

		if carbon & controlKey == controlKey {
			insert(.control)
		}

		if carbon & optionKey == optionKey {
			insert(.option)
		}

		if carbon & shiftKey == shiftKey {
			insert(.shift)
		}

		if carbon & cmdKey == cmdKey {
			insert(.command)
		}

		if carbon & Self.functionKey == Self.functionKey {
			insert(.function)
		}
	}
}

extension SwiftUI.EventModifiers {
	// `.function` is deprecated, so we use the raw value.
	nonisolated fileprivate static let function_nonDeprecated = Self(rawValue: 64)
}

extension NSEvent.ModifierFlags {
	nonisolated var toEventModifiers: SwiftUI.EventModifiers {
		var modifiers = SwiftUI.EventModifiers()

		if contains(.capsLock) {
			modifiers.insert(.capsLock)
		}

		if contains(.command) {
			modifiers.insert(.command)
		}

		if contains(.control) {
			modifiers.insert(.control)
		}

		if contains(.numericPad) {
			modifiers.insert(.numericPad)
		}

		if contains(.option) {
			modifiers.insert(.option)
		}

		if contains(.shift) {
			modifiers.insert(.shift)
		}

		if contains(.function) {
			modifiers.insert(.function_nonDeprecated)
		}

		return modifiers
	}
}

extension NSEvent.ModifierFlags {
	/**
	The string representation of the modifier flags.

	```swift
	print(NSEvent.ModifierFlags([.command, .shift]).presentableDescription)
	//=> "⇧⌘"
	```
	*/
	@available(*, deprecated, renamed: "ks_symbolicRepresentation")
	var presentableDescription: String {
		ks_symbolicRepresentation
	}
}


extension NSEvent.ModifierFlags {
	/**
	The symbolic representation of the modifier flags.

	```swift
	let modifiers = NSEvent.ModifierFlags([.command, .shift])
	print(modifiers.ks_symbolicRepresentation)
	//=> "⇧⌘"
	```
	*/
	nonisolated public var ks_symbolicRepresentation: String {
		var description = ""

		if contains(.control) {
			description += "⌃"
		}

		if contains(.option) {
			description += "⌥"
		}

		if contains(.shift) {
			description += "⇧"
		}

		if contains(.command) {
			description += "⌘"
		}

		if contains(.function) {
			description += UnicodeSymbols.functionKey
		}

		return description
	}
}


extension NSEvent.SpecialKey {
	nonisolated(unsafe) static let functionKeys: Set<Self> = [
		.f1,
		.f2,
		.f3,
		.f4,
		.f5,
		.f6,
		.f7,
		.f8,
		.f9,
		.f10,
		.f11,
		.f12,
		.f13,
		.f14,
		.f15,
		.f16,
		.f17,
		.f18,
		.f19,
		.f20,
		.f21,
		.f22,
		.f23,
		.f24,
		.f25,
		.f26,
		.f27,
		.f28,
		.f29,
		.f30,
		.f31,
		.f32,
		.f33,
		.f34,
		.f35
	]

	nonisolated var isFunctionKey: Bool { Self.functionKeys.contains(self) }
}


enum AssociationPolicy {
	case assign
	case retainNonatomic
	case copyNonatomic
	case retain
	case copy

	var rawValue: objc_AssociationPolicy {
		switch self {
		case .assign:
			.OBJC_ASSOCIATION_ASSIGN
		case .retainNonatomic:
			.OBJC_ASSOCIATION_RETAIN_NONATOMIC
		case .copyNonatomic:
			.OBJC_ASSOCIATION_COPY_NONATOMIC
		case .retain:
			.OBJC_ASSOCIATION_RETAIN
		case .copy:
			.OBJC_ASSOCIATION_COPY
		}
	}
}

// Workaround for a Swift compiler crash where the optimizer (`EarlyPerfInliner`) crashes on the
// isolated `deinit` of a generic `@MainActor` class when the deployment target is below the
// isolated-deinit availability floor. Making `ObjectAssociation` a struct (no deinit) and using a
// concrete non-generic class for the association key avoids the bug.
// https://github.com/sindresorhus/KeyboardShortcuts/issues/240
// https://github.com/swiftlang/swift/issues/89896
private final class ObjectAssociationKey {}

struct ObjectAssociation<T> {
	private let key = ObjectAssociationKey()
	private let policy: AssociationPolicy

	init(policy: AssociationPolicy = .retainNonatomic) {
		self.policy = policy
	}

	subscript(index: AnyObject) -> T? {
		get {
			// Force-cast is fine here as we want it to fail loudly if we don't use the correct type.
			// swiftlint:disable:next force_cast
			objc_getAssociatedObject(index, Unmanaged.passUnretained(key).toOpaque()) as! T?
		}
		nonmutating set {
			objc_setAssociatedObject(index, Unmanaged.passUnretained(key).toOpaque(), newValue, policy.rawValue)
		}
	}
}


extension HorizontalAlignment {
	private enum ControlAlignment: AlignmentID {
		nonisolated static func defaultValue(in context: ViewDimensions) -> CGFloat { // swiftlint:disable:this no_cgfloat
			context[HorizontalAlignment.center]
		}
	}

	nonisolated fileprivate static let controlAlignment = Self(ControlAlignment.self)
}

extension View {
	func formLabel(@ViewBuilder _ label: () -> some View) -> some View {
		HStack(alignment: .firstTextBaseline) {
			label()
			labelsHidden()
				.alignmentGuide(.controlAlignment) { $0[.leading] }
		}
		.alignmentGuide(.leading) { $0[.controlAlignment] }
	}
}


#if DEBUG
/**
Get SwiftUI dynamic shared object.

Reference: https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man3/dyld.3.html
*/
@usableFromInline
nonisolated(unsafe) let dynamicSharedObject: UnsafeMutableRawPointer = {
	let imageCount = _dyld_image_count()
	for imageIndex in 0..<imageCount {
		guard
			let name = _dyld_get_image_name(imageIndex),
			// Use `/SwiftUI` instead of `SwiftUI` to prevent any library named `XXSwiftUI`.
			String(cString: name).hasSuffix("/SwiftUI"),
			let header = _dyld_get_image_header(imageIndex)
		else {
			continue
		}

		return UnsafeMutableRawPointer(mutating: header)
	}

	return UnsafeMutableRawPointer(mutating: #dsohandle)
}()
#endif

@_transparent
@usableFromInline
nonisolated func runtimeWarn(
	_ condition: @autoclosure () -> Bool, _ message: @autoclosure () -> String
) {
#if DEBUG
#if canImport(OSLog)
	let condition = condition()
	if !condition {
		os_log(
			.fault,
			// A token that identifies the containing executable or dylib image.
			dso: dynamicSharedObject,
			log: OSLog(subsystem: "com.apple.runtime-issues", category: "KeyboardShortcuts"),
			"%@",
			message()
		)
	}
#else
	assert(condition(), message())
#endif
#endif
}

extension KeyboardShortcuts {
	nonisolated static func isValidShortcutName(_ name: String) -> Bool {
		!name.contains(".")
	}
}
#endif


@available(iOS 14.0, *)
@available(macOS 11.0, *)
extension KeyEquivalent {
	init?(unicodeScalarValue value: Int) {
		guard let character = Character(unicodeScalarValue: value) else {
			return nil
		}

		self = KeyEquivalent(character)
	}
}


extension Sequence where Element: Hashable {
	/**
	Convert a `Sequence` with `Hashable` elements to a `Set`.
	*/
	func toSet() -> Set<Element> { Set(self) }
}



extension StringProtocol {
	func replacingPrefix(_ prefix: String, with replacement: String) -> String {
		guard hasPrefix(prefix) else {
			return String(self)
		}

		return replacement + dropFirst(prefix.count)
	}
}

extension Character {
	init?(unicodeScalarValue value: Int) {
		guard let content = UnicodeScalar(value) else {
			return nil
		}

		self = Character(content)
	}
}

enum NotificationUserInfoKey {
	nonisolated static let name = "name"
	nonisolated static let isActive = "isActive"
}

extension Notification {
	nonisolated var keyboardShortcutsName: KeyboardShortcuts.Name? {
		userInfo?[NotificationUserInfoKey.name] as? KeyboardShortcuts.Name
	}

	nonisolated var recorderIsActive: Bool {
		(userInfo?[NotificationUserInfoKey.isActive] as? Bool) ?? false
	}
}
